/**
 * Auth Routes
 * POST /api/auth/login   — validate credentials, return JWT
 * POST /api/auth/logout  — clear token
 * GET  /api/auth/me      — return current user info
 */
const express = require('express');
const jwt     = require('jsonwebtoken');
const { authenticate, allPublic } = require('../config/students');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

const JWT_SECRET  = () => process.env.JWT_SECRET || 'dev-secret-change-me';
const JWT_EXPIRES = () => process.env.JWT_EXPIRES_IN || '7d';

/**
 * POST /api/auth/login
 * Body: { no: "27", password: "anapatmaliwong59892" }
 * Returns: { token, user: { no, first, last, role } }
 */
router.post('/login', (req, res) => {
  const { no, password } = req.body;

  if (!no || !password) {
    return res.status(400).json({ error: 'กรุณากรอกเลขที่และรหัส' });
  }

  const user = authenticate(no, password);
  if (!user) {
    // Generic message — don't reveal whether no or password was wrong
    return res.status(401).json({ error: 'เลขที่หรือรหัสประจำตัวไม่ถูกต้อง' });
  }

  const token = jwt.sign(user, JWT_SECRET(), { expiresIn: JWT_EXPIRES() });

  res.json({ token, user });
});

/**
 * GET /api/auth/me
 * Returns current user info (reads JWT)
 */
router.get('/me', requireAuth, (req, res) => {
  res.json({ user: req.user });
});

/**
 * GET /api/auth/students
 * Returns all students WITHOUT passwords (safe for browser)
 */
router.get('/students', requireAuth, (req, res) => {
  res.json({ students: allPublic() });
});

/**
 * POST /api/auth/logout
 * Client should delete its token; nothing to do server-side for JWT
 */
router.post('/logout', (req, res) => {
  res.json({ ok: true });
});

module.exports = router;
