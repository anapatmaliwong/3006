/**
 * api.js — Frontend API Client
 * All calls go to /api/... on our backend.
 * The browser never touches Firebase or Gemini directly.
 */

const API = (() => {

  // Store token in memory + localStorage
  let _token = localStorage.getItem('3006_token') || null;

  function setToken(t) {
    _token = t;
    if (t) localStorage.setItem('3006_token', t);
    else localStorage.removeItem('3006_token');
  }

  function getToken() { return _token; }

  async function request(method, path, body) {
    const headers = { 'Content-Type': 'application/json' };
    if (_token) headers['Authorization'] = 'Bearer ' + _token;

    const opts = { method, headers };
    if (body) opts.body = JSON.stringify(body);

    const res = await fetch('/api' + path, opts);

    // Token expired — redirect to login
    if (res.status === 401) {
      setToken(null);
      window.location.href = '/?reason=expired';
      return;
    }

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Request failed');
    return data;
  }

  const get    = (path)        => request('GET',    path);
  const post   = (path, body)  => request('POST',   path, body);
  const del    = (path)        => request('DELETE', path);

  // ── Auth ──────────────────────────────────────────────────────
  async function login(no, password) {
    const data = await post('/auth/login', { no, password });
    setToken(data.token);
    return data.user;
  }

  async function logout() {
    await post('/auth/logout').catch(() => {});
    setToken(null);
    window.location.href = '/';
  }

  async function getMe() {
    if (!_token) return null;
    try { return (await get('/auth/me')).user; }
    catch { setToken(null); return null; }
  }

  async function getStudents() {
    return (await get('/auth/students')).students;
  }

  // ── Subjects ──────────────────────────────────────────────────
  async function getSubject(subject) {
    return get('/data/subjects/' + subject);
  }

  async function setSubject(subject, data) {
    return post('/data/subjects/' + subject, data);
  }

  // ── Briefs ────────────────────────────────────────────────────
  async function getBriefs() {
    return (await get('/data/briefs')).briefs;
  }

  async function postBrief(title, body, tag, expiresAt) {
    return post('/data/briefs', { title, body, tag, expiresAt });
  }

  async function deleteBrief(id) {
    return del('/data/briefs/' + id);
  }

  // ── Community ─────────────────────────────────────────────────
  async function getCommunity() {
    return (await get('/data/community')).posts;
  }

  async function postCommunity(text) {
    return post('/data/community', { text });
  }

  async function likeCommunity(id) {
    return post(`/data/community/${id}/like`);
  }

  async function replyCommunity(id, text) {
    return post(`/data/community/${id}/reply`, { text });
  }

  async function deleteCommunity(id) {
    return del('/data/community/' + id);
  }

  // ── XP ────────────────────────────────────────────────────────
  async function getXP() {
    return (await get('/data/xp')).xp;
  }

  async function addXP(amount) {
    return post('/data/xp/add', { amount });
  }

  async function adjustXP(targetNo, amount) {
    return post('/data/xp/adjust', { targetNo, amount });
  }

  async function resetAllXP() {
    return post('/data/xp/reset-all');
  }

  // ── Lobby Cards ───────────────────────────────────────────────
  async function getLobbyCards() {
    return (await get('/data/lobby-cards')).cards;
  }

  async function setLobbyCard(card) {
    return post('/data/lobby-cards', card);
  }

  async function deleteLobbyCard(id) {
    return del('/data/lobby-cards/' + id);
  }

  // ── Banners ───────────────────────────────────────────────────
  async function getBanners() {
    return (await get('/data/banners')).banners;
  }

  async function setBanners(data) {
    return post('/data/banners', data);
  }

  // ── AI ────────────────────────────────────────────────────────
  async function parseQuiz(text) {
    return post('/ai/parse-quiz', { text });
  }

  async function checkPost(postId, text) {
    return post('/ai/check-post', { postId, text });
  }

  return {
    getToken, setToken,
    login, logout, getMe, getStudents,
    getSubject, setSubject,
    getBriefs, postBrief, deleteBrief,
    getCommunity, postCommunity, likeCommunity, replyCommunity, deleteCommunity,
    getXP, addXP, adjustXP, resetAllXP,
    getLobbyCards, setLobbyCard, deleteLobbyCard,
    getBanners, setBanners,
    parseQuiz, checkPost,
  };
})();
